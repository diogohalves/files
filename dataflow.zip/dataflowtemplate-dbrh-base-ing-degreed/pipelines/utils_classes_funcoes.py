"""
utils_classes_funcoes.py
Agrupa, num arquivo só (igual ao template), tudo que o pipeline usa:

  CONFIG      -> ENDPOINTS: lista de endpoints, com habilitar/desabilitar e
                 tipo de janela (None = sem filtro de data; 7 = janela de 7 dias)
  CLASSES     -> AvroSink (grava Avro com schema inferido em string anulável)
  FUNÇÕES     -> get_secret_keys, get_token, seleciona_endpoints,
                 calcula_janelas, busca_endpoint, _paginar, normaliza_nan,
                 nomeia_o_arquivo

Nenhuma modelagem/junção é feita aqui: cada endpoint é aterrissado cru em Avro.
A modelagem acontece depois, no BigQuery (outro time).
"""
import os
import json
import uuid
import logging
from datetime import datetime, timedelta, timezone

import requests
import fastavro  # type: ignore
from google.cloud import secretmanager
from apache_beam.io.fileio import FileSink


# =============================================================
#                        CONFIG
# =============================================================
# Mapa de endpoints da API do Degreed.
# O endpoint a ser ingerido é informado por parâmetro (--endpoint) pelo
# Chameleon; este mapa apenas resolve a rota e a necessidade de janela.
#
# janela:  None -> endpoint sem filtro de data
#          7    -> a API limita a consulta a 7 dias (quebrada automaticamente)
ENDPOINTS = {
    "users":               {"path": "/api/v2/users",               "janela": None},
    "content":             {"path": "/api/v2/content",             "janela": None},
    "pathways":            {"path": "/api/v2/pathways",            "janela": None},
    "groups":              {"path": "/api/v2/groups",              "janela": None},
    "accomplishments":     {"path": "/api/v2/accomplishments",     "janela": None},
    "certificates":        {"path": "/api/v2/certificates",        "janela": None},
    "organization_skills": {"path": "/api/v2/organization-skills", "janela": None},
    "skill_ratings":       {"path": "/api/v2/skill-ratings",       "janela": None},
    "user_skills":         {"path": "/api/v2/user-skills",         "janela": None},
    "logins":              {"path": "/api/v2/logins",              "janela": 7},
    "completions":         {"path": "/api/v2/completions",         "janela": 7},
    "required_learning":   {"path": "/api/v2/required-learning",   "janela": 7},
}


# =============================================================
#                        CLASSES
# =============================================================
class AvroSink(FileSink):
    """
    Grava registros (dicts) em Avro. Se nenhum schema for informado, infere
    um schema com TODAS as colunas como string anulável (["null","string"]),
    padrão robusto para camada raw/landing: o schema não quebra entre
    execuções e a tipagem final fica a cargo do BigQuery.

    Diferença em relação ao template: o schema é inferido pela UNIÃO das
    chaves de todos os registros do buffer (não só a primeira linha), e cada
    linha é normalizada para conter todas as colunas. Isso evita erro quando
    registros do mesmo endpoint vêm com conjuntos de campos diferentes.
    """
    def __init__(self, schema=None):
        self.schema = schema

    def open(self, fh):
        self._fh = fh
        self._buffer = []

    def write(self, record):
        # ignora a key da tupla dinâmica (quando vier de destino por chave)
        if isinstance(record, tuple) and len(record) == 2:
            record = record[1]
        if isinstance(record, list):
            self._buffer.extend(record)
        elif isinstance(record, dict):
            self._buffer.append(record)

    def flush(self):
        if self._buffer:
            if not self.schema:
                # união das chaves de todos os registros
                colunas = []
                vistas = set()
                for row in self._buffer:
                    for k in row.keys():
                        if k not in vistas:
                            vistas.add(k)
                            colunas.append(str(k))
                fields = [{"name": c, "type": ["null", "string"], "default": None} for c in colunas]
                schema_dict = {"type": "record", "name": "DegreedData", "fields": fields}
            else:
                schema_dict = self.schema
                colunas = [f["name"] for f in schema_dict["fields"]]

            parsed_schema = fastavro.parse_schema(schema_dict)

            # normaliza: todo valor vira string anulável; garante todas as colunas
            norm_records = []
            for row in self._buffer:
                norm_row = {}
                for c in colunas:
                    v = row.get(c)
                    if v is None:
                        norm_row[c] = None
                    elif isinstance(v, (dict, list)):
                        norm_row[c] = json.dumps(v, ensure_ascii=False)
                    else:
                        norm_row[c] = str(v)
                norm_records.append(norm_row)

            fastavro.writer(self._fh, parsed_schema, norm_records, codec="snappy")
            self._buffer = []
        self._fh.flush()


# =============================================================
#                        FUNÇÕES
# =============================================================
def get_secret_keys(secret_manager_project_id, secret_key, version_id="1"):
    """Busca o segredo armazenado no Secret Manager do GCP."""
    try:
        client = secretmanager.SecretManagerServiceClient()
        secret_name = f"projects/{secret_manager_project_id}/secrets/{secret_key}/versions/{version_id}"
        response = client.access_secret_version(request={"name": secret_name})
        return response.payload.data.decode("UTF-8")
    except Exception as e:
        logging.error(f"Erro ao acessar o Secret Manager: {e}")
        return None


def resolve_credenciais(secret_project, secret_client_id, secret_client_secret):
    """
    Decide de onde vêm as credenciais do Degreed:

    - Se secret_project + os nomes dos secrets forem informados -> Secret Manager
      (padrão de produção / Dataflow).
    - Caso contrário -> variáveis de ambiente DEGREED_CLIENT_ID e
      DEGREED_CLIENT_SECRET (uso local, sem depender do GCP).

    Retorna (client_id, client_secret).
    """
    usa_sm = bool(secret_project and secret_client_id and secret_client_secret)

    if usa_sm:
        cid = get_secret_keys(secret_project, secret_client_id, "latest")
        csec = get_secret_keys(secret_project, secret_client_secret, "latest")
        origem = "Secret Manager"
    else:
        cid = os.getenv("DEGREED_CLIENT_ID", "")
        csec = os.getenv("DEGREED_CLIENT_SECRET", "")
        origem = "variáveis de ambiente"

    if not cid or not csec:
        raise EnvironmentError(
            f"Credenciais do Degreed não encontradas ({origem}). "
            "Para uso local, defina DEGREED_CLIENT_ID e DEGREED_CLIENT_SECRET; "
            "para produção, informe --secret_manager_project_id e os nomes dos secrets."
        )

    logging.warning(f"Credenciais obtidas via {origem}.")
    return cid, csec


def get_token(oauth_url, client_id, client_secret, scope):
    """Obtém o access_token OAuth (client_credentials) do Degreed."""
    resp = requests.post(
        oauth_url,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": scope,
        },
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def resolve_endpoint(nome):
    """
    Resolve o endpoint informado por parâmetro (--endpoint) no mapa ENDPOINTS,
    devolvendo o spec com nome, path e janela.

    Levanta ValueError quando o endpoint não existe no mapa, para o job falhar
    cedo em vez de gravar um arquivo vazio.
    """
    if not nome or nome.strip() not in ENDPOINTS:
        raise ValueError(
            f"Endpoint invalido: {nome!r}. Validos: {sorted(ENDPOINTS)}"
        )
    nome = nome.strip()
    return {"nome": nome, **ENDPOINTS[nome]}


def calcula_janelas(lookback_days, max_dias=7):
    """
    Quebra o período [hoje - lookback_days, hoje] em janelas de no máximo
    max_dias dias. Retorna lista de tuplas (inicio, fim) em 'YYYY-MM-DD'.
    """
    fim = datetime.now(timezone.utc)
    inicio = fim - timedelta(days=lookback_days)
    janelas = []
    cursor = inicio
    while cursor < fim:
        janela_fim = min(cursor + timedelta(days=max_dias), fim)
        janelas.append((cursor.strftime("%Y-%m-%d"), janela_fim.strftime("%Y-%m-%d")))
        cursor = janela_fim
    return janelas


def _paginar(url, params, headers, nome, ingested_at):
    """Pagina um endpoint (links.next) e emite cada registro achatado."""
    while url:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()
        for item in payload.get("data", []):
            reg = {"id": item.get("id")}
            reg.update(item.get("attributes", {}))
            reg["source_endpoint"] = nome
            reg["ingested_at"] = ingested_at
            yield reg
        url = payload.get("links", {}).get("next")
        params = None  # já embutido no next link


def busca_endpoint(spec, api_base, token, lookback):
    """
    Gerador que consome um endpoint inteiro.
    - spec["janela"] is None -> full (sem filtro de data)
    - spec["janela"] == 7    -> quebra em janelas de 7 dias
    """
    path = spec["path"]
    nome = spec["nome"]
    janela = spec.get("janela")
    ingested_at = datetime.now(timezone.utc).isoformat()
    headers = {"Authorization": f"Bearer {token}"}

    if not janela:
        yield from _paginar(api_base + path, {"page[size]": 100}, headers, nome, ingested_at)
    else:
        for inicio, fim in calcula_janelas(lookback, janela):
            params = {
                "filter[start_date]": inicio,
                "filter[end_date]": fim,
                "page[size]": 100,
            }
            yield from _paginar(api_base + path, params, headers, nome, ingested_at)


def normaliza_nan(d):
    """Troca 'nan' (gerado pelo pandas) por None em list/dict aninhados."""
    if isinstance(d, dict):
        return {k: (None if str(v) == "nan" else v) for k, v in d.items()}
    elif isinstance(d, list):
        return [normaliza_nan(i) for i in d]
    else:
        return d


def nomeia_o_arquivo(nome, ext=".avro"):
    """
    Monta o nome do arquivo de saída. Usada em conjunto com WriteToFiles.
    Ex.: users_<uuid>.avro
    """
    def _inner(window, pane, shard_index, total_shards, compression, destination):
        uid = uuid.uuid4()
        return f"{nome}_{uid}{ext}"
    return _inner
