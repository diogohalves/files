"""
my_pipeline.py
Monta o pipeline Beam. Cada execucao ingere UM endpoint da API do Degreed,
informado em --endpoint pelo Chameleon, e grava o retorno cru em avro no
caminho de processamento recebido em --prefixOut.
"""
import logging

import apache_beam as beam
from apache_beam.io.fileio import WriteToFiles
from apache_beam.options.pipeline_options import PipelineOptions

from pipelines.my_options import MyOptions
from pipelines.utils_classes_funcoes import (
    AvroSink,
    busca_endpoint,
    get_token,
    nomeia_o_arquivo,
    resolve_credenciais,
    resolve_endpoint,
)


def run(argv=None):
    my_options = PipelineOptions(argv).view_as(MyOptions)

    # Resolve o endpoint informado por parametro no mapa de endpoints
    spec = resolve_endpoint(my_options.endpoint)

    # Credenciais (Secret Manager em producao; variaveis de ambiente no local)
    client_id, client_secret = resolve_credenciais(
        my_options.secret_manager_project_id,
        my_options.client_id,
        my_options.client_secret
    )
    token = get_token(my_options.oauth_url, client_id, client_secret, my_options.scope)

    dias_delta = int(my_options.dias_delta)

    logging.warning(f"Endpoint: {spec['nome']} | dias_delta: {dias_delta} | janela: {spec['janela']}")

    # Monta o pipeline e grava os dados crus em avro para processamento posterior pelo Chameleon
    with beam.Pipeline(options=my_options) as pipeline:
        (
            pipeline
            | "Gatilho Inicial" >> beam.Create([spec])
            | "Chamar API" >> beam.FlatMap(
                busca_endpoint,
                api_base=my_options.api_path,
                token=token,
                lookback=dias_delta
            )
            | "Salva arquivo API" >> WriteToFiles(
                path=my_options.prefixOut,
                file_naming=nomeia_o_arquivo(spec['nome'], ext=".avro"),
                sink=AvroSink()
            )
        )
