from apache_beam.options.pipeline_options import PipelineOptions


class MyOptions(PipelineOptions):
    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_argument('--endpoint', required=False, help='Endpoint da API a ser ingerido')
        parser.add_argument('--api_path', required=False, help='Rota da chamada')
        parser.add_argument('--oauth_url', required=False, help='Endereco do endpoint de autenticacao (OAuth)')
        parser.add_argument('--scope', required=False, help='Escopos OAuth necessarios para o endpoint')
        parser.add_argument('--dias_delta', required=False, help='Quantidade de dias retroativos para extracao dos dados')
        parser.add_argument('--secret_manager_project_id', required=False, help='Secret manager project id')
        parser.add_argument('--client_id', required=False, help='Nome do segredo com o client id da api degreed')
        parser.add_argument('--client_secret', required=False, help='Nome do segredo com o client secret da api degreed')
        parser.add_argument('--prefixOut', required=False, help='Caminho de processamento dos arquivos avro')
