"""Setup.py para empacotar o pipeline nos workers do Dataflow."""
import setuptools

# Pacotes necessários para a execução da pipeline no Dataflow
REQUIRED_PACKAGES = [
    "apache-beam[gcp]==2.57.0",
    "google-cloud-secret-manager==2.20.0",
    "requests==2.31.0",
    "fastavro==1.9.4",
    "cramjam==2.8.3",   # codec snappy usado pelo fastavro
]

# Pacotes apenas para desenvolvimento e testes locais
DEV_PACKAGES = [
    "pytest==8.2.2",
    "pytest-cov==5.0.0",
    "flake8==7.1.0",
]

setuptools.setup(
    name="dataflowtemplate-dbrh-base-ing-degreed",
    version="0.1.0",
    description="Componente de ingestão da API Degreed via Dataflow (Beam Python) para Avro no GCS",
    install_requires=REQUIRED_PACKAGES,
    extras_require={"dev": DEV_PACKAGES},
    packages=setuptools.find_packages(),
)
