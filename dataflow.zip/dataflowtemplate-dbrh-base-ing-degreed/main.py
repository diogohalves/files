"""
main.py
Entrypoint do template Dataflow. Chama o run() do pipeline.
"""
import logging

from pipelines.my_pipeline import run

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    run()
