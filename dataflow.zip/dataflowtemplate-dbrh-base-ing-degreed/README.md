# Projeto Dataflow Python para Consulta de API em ambiente isolado (Confidential Space)

Extracao de dados da API do Degreed. Cada execucao ingere UM endpoint,
informado no parametro `endpoint` pelo Chameleon, e grava o retorno cru em
avro no caminho de processamento. A selecao de campos e a modelagem ocorrem
depois, no Chameleon.

## Iniciar o projeto

Instalação de dependências de execução e desenvolvimento:

Com o terminal na pasta do projeto, crie um Ambiente Virtual para o Python:
```bash
python -m venv venv
```

Ative o ambiente virtual:
```bash
source venv/Scripts/activate
```

Atualize seu pip:
```bash
python -m pip install --upgrade pip
```

Instale as dependências:
```bash
pip install -r requirements.txt --force-reinstall
```

## Execucao em DES

Substituir valores conforme a origem e o destino.

```bash
python main.py \
  --endpoint "users" \
  --api_path "https://api.degreed.com" \
  --oauth_url "https://degreed.com/oauth/token" \
  --scope "users:read" \
  --dias_delta "7" \
  --secret_manager_project_id "0000000000000" \
  --client_id "degreed_client_id" \
  --client_secret "degreed_client_secret" \
  --prefixOut "outputOp"
```

## Endpoints disponiveis

Sem filtro de data: `users`, `content`, `pathways`, `groups`,
`accomplishments`, `certificates`, `organization_skills`, `skill_ratings`,
`user_skills`.

Com limite de 7 dias por consulta (fatiados automaticamente conforme o
`dias_delta`): `logins`, `completions`, `required_learning`.

## Secrets da API Degreed

### Secret: "degreed_client_id"
projects/0000000000000/secrets/degreed_client_id

### Secret: "degreed_client_secret"
projects/0000000000000/secrets/degreed_client_secret

## Testes unitários

```bash
python -m pytest tests/unit -ra
```

# Documentação
- [Desenho do projeto](<PREENCHER: link do Confluence>)
