from unittest import TestCase


assert_count_equal = TestCase().assertCountEqual
