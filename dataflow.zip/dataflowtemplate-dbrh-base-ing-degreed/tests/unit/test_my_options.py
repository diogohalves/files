import pytest
from pipelines.my_options import MyOptions


def test_my_options_parsing():
    """
    Testa se a classe MyOptions processa corretamente os argumentos
    de linha de comando esperados pela pipeline.
    """
    argv = [
        '--endpoint=users',
        '--api_path=https://api.degreed.com',
        '--oauth_url=https://degreed.com/oauth/token',
        '--scope=users:read',
        '--dias_delta=7',
        '--secret_manager_project_id=123456789',
        '--client_id=degreed_client_id',
        '--client_secret=degreed_client_secret',
        '--prefixOut=gs://meu-bucket/pasta_tmp'
    ]

    options = MyOptions(argv)

    # Valida se cada atributo foi extraido corretamente
    assert options.endpoint == 'users'
    assert options.api_path == 'https://api.degreed.com'
    assert options.oauth_url == 'https://degreed.com/oauth/token'
    assert options.scope == 'users:read'
    assert options.dias_delta == '7'
    assert options.secret_manager_project_id == '123456789'
    assert options.client_id == 'degreed_client_id'
    assert options.client_secret == 'degreed_client_secret'
    assert options.prefixOut == 'gs://meu-bucket/pasta_tmp'


def test_my_options_missing_args():
    """
    Testa o comportamento da classe quando argumentos sao omitidos.
    """
    options = MyOptions([])
    assert options.endpoint is None
