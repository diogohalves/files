import pytest


@pytest.fixture(scope="session")
def x():
    return "unittest"
