import io
import json
import pytest
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock

# Import das funções/classes a serem testadas
from pipelines.utils_classes_funcoes import (
    AvroSink, ENDPOINTS, get_secret_keys, resolve_credenciais, get_token,
    resolve_endpoint, calcula_janelas, busca_endpoint, normaliza_nan,
    nomeia_o_arquivo
)


@pytest.fixture
def dados_mock():
    """Fixture que retorna dados fictícios em formato de dicionário para os testes."""
    return [
        {'id': '1', 'nome': 'Ana', 'nota': 5, 'tags': ['a', 'b']},
        {'id': '2', 'nome': 'Bruno', 'status': None}
    ]


@pytest.fixture
def resposta_pagina_unica():
    """Fixture que simula uma resposta da API com 2 registros e sem próxima página."""
    resposta = MagicMock()
    resposta.json.return_value = {
        "data": [
            {"id": "1", "attributes": {"nome": "Ana", "status": "completed"}},
            {"id": "2", "attributes": {"nome": "Bruno", "status": None}}
        ],
        "links": {"next": None}
    }
    return resposta


# -----------------------------------------------------------------------------
# TESTES DA CLASSE AvroSink
# -----------------------------------------------------------------------------

def test_avro_sink(dados_mock):
    """
    Testa o AvroSink criando o arquivo em memória para validar
    a inferência do schema e a gravação compactada usando fastavro.
    """
    import fastavro
    sink = AvroSink()
    mock_file = io.BytesIO()

    sink.open(mock_file)
    for dado in dados_mock:
        sink.write(dado)
    sink.flush()

    # Move o ponteiro do byte de volta para o início e lê o arquivo avro binário
    mock_file.seek(0)
    reader = fastavro.reader(mock_file)
    campos = [campo['name'] for campo in reader.writer_schema['fields']]
    registros = list(reader)

    assert len(registros) == 2
    # O schema é a união das chaves de todos os registros
    assert set(campos) == {'id', 'nome', 'nota', 'tags', 'status'}
    assert registros[0]['nota'] == "5"  # Forçamos string na conversão inteligente do sink
    assert registros[0]['tags'] == json.dumps(['a', 'b'])  # Aninhados viram json string
    assert registros[1]['status'] is None
    assert registros[1]['nota'] is None  # Coluna ausente no registro vira nulo


def test_avro_sink_ignora_key_da_tupla(dados_mock):
    """
    Testa se o sink descarta a chave da tupla dinâmica criada pelo WriteToFiles,
    gravando apenas o registro.
    """
    import fastavro
    sink = AvroSink()
    mock_file = io.BytesIO()

    sink.open(mock_file)
    sink.write(('users', dados_mock[0]))
    sink.flush()

    mock_file.seek(0)
    registros = list(fastavro.reader(mock_file))

    assert len(registros) == 1
    assert registros[0]['id'] == '1'


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO get_secret_keys
# -----------------------------------------------------------------------------

@patch('pipelines.utils_classes_funcoes.secretmanager.SecretManagerServiceClient')
def test_get_secret_keys_sucesso(mock_secret_client):
    """
    Testa o cenário de sucesso onde a chave é encontrada no Secret Manager.
    Valida a construção correta do nome do recurso e a decodificação UTF-8.
    """
    # Configura o mock da instância do cliente e da estrutura de resposta
    mock_instance = MagicMock()
    mock_response = MagicMock()
    mock_response.payload.data.decode.return_value = "chave_super_secreta"
    mock_instance.access_secret_version.return_value = mock_response
    mock_secret_client.return_value = mock_instance

    resultado = get_secret_keys('123456789', 'degreed-client-id', 'latest')

    assert resultado == "chave_super_secreta"
    mock_instance.access_secret_version.assert_called_once_with(
        request={"name": "projects/123456789/secrets/degreed-client-id/versions/latest"}
    )


@patch('pipelines.utils_classes_funcoes.secretmanager.SecretManagerServiceClient')
def test_get_secret_keys_falha(mock_secret_client):
    """
    Testa o cenário onde ocorre uma exceção na chamada da API do Secret Manager.
    Espera-se que a função trate o erro e retorne None.
    """
    mock_instance = MagicMock()
    mock_instance.access_secret_version.side_effect = Exception("Permissão negada ou Segredo inexistente")
    mock_secret_client.return_value = mock_instance

    resultado = get_secret_keys('123456789', 'degreed-client-id')

    assert resultado is None


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO resolve_credenciais
# -----------------------------------------------------------------------------

@patch('pipelines.utils_classes_funcoes.get_secret_keys')
def test_resolve_credenciais_secret_manager(mock_get_secret_keys):
    """
    Testa se as credenciais são buscadas no Secret Manager quando o projeto
    e os nomes dos segredos são informados (cenário de produção).
    """
    mock_get_secret_keys.side_effect = lambda proj, nome, ver: f"valor_{nome}"

    client_id, client_secret = resolve_credenciais(
        '123456789', 'degreed-client-id', 'degreed-client-secret'
    )

    assert client_id == 'valor_degreed-client-id'
    assert client_secret == 'valor_degreed-client-secret'
    assert mock_get_secret_keys.call_count == 2


def test_resolve_credenciais_variaveis_de_ambiente(monkeypatch):
    """
    Testa o fallback para variáveis de ambiente quando os segredos não são
    informados (cenário de execução local).
    """
    monkeypatch.setenv('DEGREED_CLIENT_ID', 'id_local')
    monkeypatch.setenv('DEGREED_CLIENT_SECRET', 'secret_local')

    client_id, client_secret = resolve_credenciais('', '', '')

    assert client_id == 'id_local'
    assert client_secret == 'secret_local'


def test_resolve_credenciais_ausentes(monkeypatch):
    """
    Testa se a função levanta erro quando não há credenciais em nenhuma origem.
    """
    monkeypatch.delenv('DEGREED_CLIENT_ID', raising=False)
    monkeypatch.delenv('DEGREED_CLIENT_SECRET', raising=False)

    with pytest.raises(EnvironmentError):
        resolve_credenciais('', '', '')


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO get_token
# -----------------------------------------------------------------------------

@patch('pipelines.utils_classes_funcoes.requests.post')
def test_get_token(mock_post):
    """
    Testa a obtenção do token OAuth validando o payload enviado
    no fluxo client_credentials.
    """
    mock_resposta = MagicMock()
    mock_resposta.json.return_value = {"access_token": "token_de_acesso", "expires_in": 3600}
    mock_post.return_value = mock_resposta

    token = get_token(
        'https://degreed.com/oauth/token', 'meu_id', 'meu_secret', 'users:read'
    )

    assert token == "token_de_acesso"
    _, kwargs = mock_post.call_args
    assert kwargs['data']['grant_type'] == 'client_credentials'
    assert kwargs['data']['client_id'] == 'meu_id'
    assert kwargs['data']['scope'] == 'users:read'


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO resolve_endpoint
# -----------------------------------------------------------------------------

def test_resolve_endpoint_sem_janela():
    """Testa a resolução de um endpoint que não possui filtro de data."""
    resultado = resolve_endpoint('users')

    assert resultado['nome'] == 'users'
    assert resultado['path'] == '/api/v2/users'
    assert resultado['janela'] is None


def test_resolve_endpoint_com_janela():
    """Testa a resolução de um endpoint limitado a 7 dias por consulta."""
    resultado = resolve_endpoint('completions')

    assert resultado['nome'] == 'completions'
    assert resultado['janela'] == 7


def test_resolve_endpoint_todos_mapeados():
    """Garante que todo endpoint do mapa possui path e chave de janela."""
    for nome in ENDPOINTS:
        spec = resolve_endpoint(nome)
        assert spec['path'].startswith('/api/v2/')
        assert spec['janela'] in (None, 7)


def test_resolve_endpoint_invalido():
    """
    Testa se um endpoint inexistente levanta erro, fazendo o job falhar cedo
    em vez de gravar um arquivo vazio.
    """
    with pytest.raises(ValueError):
        resolve_endpoint('nao_existe')


def test_resolve_endpoint_vazio():
    """Testa se a ausência do parâmetro endpoint também levanta erro."""
    with pytest.raises(ValueError):
        resolve_endpoint('')


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO calcula_janelas
# -----------------------------------------------------------------------------

def test_calcula_janelas_quebra_em_sete_dias():
    """
    Testa se um período maior que o limite da API é quebrado em janelas
    de no máximo 7 dias.
    """
    resultado = calcula_janelas(24, max_dias=7)

    # 24 dias -> 4 janelas (7 + 7 + 7 + 3)
    assert len(resultado) == 4
    for inicio, fim in resultado:
        assert len(inicio) == 10 and len(fim) == 10  # formato YYYY-MM-DD


def test_calcula_janelas_periodo_curto():
    """Testa se um período menor que 7 dias gera uma única janela."""
    resultado = calcula_janelas(3, max_dias=7)

    assert len(resultado) == 1


def test_calcula_janelas_continuidade():
    """Testa se o fim de uma janela é o início da seguinte, sem buracos."""
    resultado = calcula_janelas(21, max_dias=7)

    for anterior, proxima in zip(resultado, resultado[1:]):
        assert anterior[1] == proxima[0]


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO busca_endpoint
# -----------------------------------------------------------------------------

@patch('pipelines.utils_classes_funcoes.requests.get')
def test_busca_endpoint_sem_janela(mock_get, resposta_pagina_unica):
    """
    Testa um endpoint sem filtro de data, validando o achatamento do JSON:API
    e a adição dos metadados da camada raw.
    """
    mock_get.return_value = resposta_pagina_unica
    spec = {'nome': 'users', 'path': '/api/v2/users', 'janela': None}

    resultado = list(busca_endpoint(spec, api_base='https://api.degreed.com', token='T', lookback=3))

    assert len(resultado) == 2
    assert resultado[0]['id'] == '1'
    assert resultado[0]['nome'] == 'Ana'  # veio de "attributes"
    assert resultado[0]['source_endpoint'] == 'users'
    assert 'ingested_at' in resultado[0]
    assert mock_get.call_count == 1


@patch('pipelines.utils_classes_funcoes.requests.get')
def test_busca_endpoint_com_janela(mock_get, resposta_pagina_unica):
    """
    Testa um endpoint com janela de 7 dias, garantindo uma chamada por janela
    e o envio dos filtros de data.
    """
    mock_get.return_value = resposta_pagina_unica
    spec = {'nome': 'completions', 'path': '/api/v2/completions', 'janela': 7}

    # lookback de 14 dias -> 2 janelas -> 2 chamadas -> 4 registros
    resultado = list(busca_endpoint(spec, api_base='https://api.degreed.com', token='T', lookback=14))

    assert len(resultado) == 4
    assert mock_get.call_count == 2

    _, kwargs = mock_get.call_args
    assert 'filter[start_date]' in kwargs['params']
    assert 'filter[end_date]' in kwargs['params']


@patch('pipelines.utils_classes_funcoes.requests.get')
def test_busca_endpoint_paginacao(mock_get):
    """
    Testa se a paginação segue o links.next até a última página.
    """
    pagina1 = MagicMock()
    pagina1.json.return_value = {
        "data": [{"id": "1", "attributes": {}}],
        "links": {"next": "https://api.degreed.com/api/v2/users?page=2"}
    }
    pagina2 = MagicMock()
    pagina2.json.return_value = {
        "data": [{"id": "2", "attributes": {}}],
        "links": {"next": None}
    }
    mock_get.side_effect = [pagina1, pagina2]

    spec = {'nome': 'users', 'path': '/api/v2/users', 'janela': None}
    resultado = list(busca_endpoint(spec, api_base='https://api.degreed.com', token='T', lookback=3))

    assert [r['id'] for r in resultado] == ['1', '2']
    assert mock_get.call_count == 2


@patch('pipelines.utils_classes_funcoes.requests.get')
def test_busca_endpoint_envia_bearer(mock_get, resposta_pagina_unica):
    """Testa se o token é enviado no cabeçalho Authorization como Bearer."""
    mock_get.return_value = resposta_pagina_unica
    spec = {'nome': 'users', 'path': '/api/v2/users', 'janela': None}

    list(busca_endpoint(spec, api_base='https://api.degreed.com', token='meu_token', lookback=3))

    _, kwargs = mock_get.call_args
    assert kwargs['headers']['Authorization'] == 'Bearer meu_token'


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO normaliza_nan
# -----------------------------------------------------------------------------

def test_normaliza_nan_dicionario():
    """
    Testa se a função substitui valores 'nan' (string ou float) por None
    quando estão formatados dentro de um dicionário.
    """
    dado_entrada = {
        "id": 1,
        "tag_valida": "teste",
        "tag_str_nula": "nan",
        "tag_float_nula": float("nan")
    }
    resultado = normaliza_nan(dado_entrada)

    assert resultado["tag_valida"] == "teste"
    assert resultado["tag_str_nula"] is None
    assert resultado["tag_float_nula"] is None


def test_normaliza_nan_lista_e_aninhados():
    """
    Testa se a recursividade funciona corretamente ao receber uma
    lista contendo dicionários aninhados.
    """
    dado_entrada = [
        {"id": 1, "status": "nan"},
        {"id": 2, "status": "resolvido"}
    ]
    resultado = normaliza_nan(dado_entrada)

    assert resultado[0]["status"] is None
    assert resultado[1]["status"] == "resolvido"


# -----------------------------------------------------------------------------
# TESTES DA FUNÇÃO nomeia_o_arquivo
# -----------------------------------------------------------------------------

def test_nomeia_o_arquivo():
    """
    Testa a função nomeia_o_arquivo que retorna um callable (closure)
    compatível com o argumento file_naming da PTransform WriteToFiles do Apache Beam.
    """
    # Obtém a função interna já configurada com o nome do endpoint e a extensão
    funcao_nomeadora = nomeia_o_arquivo('users', ext='.avro')

    # Executa a função simulando os argumentos injetados dinamicamente pelo Beam
    nome_gerado = funcao_nomeadora(
        window=None,
        pane=None,
        shard_index=0,
        total_shards=1,
        compression=None,
        destination='minha_chave_destino'
    )

    assert nome_gerado.startswith('users_')
    assert nome_gerado.endswith('.avro')
    assert len(nome_gerado) > len('users_.avro')  # Garante que o UUID foi concatenado
