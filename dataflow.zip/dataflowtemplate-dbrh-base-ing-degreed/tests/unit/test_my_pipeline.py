import os
import fastavro
from unittest.mock import patch
from pipelines.my_pipeline import run

# --- Fakes para substituir Mocks não-serializáveis ---


def fake_busca_endpoint(spec, api_base, token, lookback):
    """
    Função "fake" que imita busca_endpoint de forma serializável,
    retornando um gerador com os dados que o teste espera.
    """
    yield {
        'id': '1',
        'nome': 'Ana',
        'source_endpoint': spec['nome'],
        'ingested_at': '2026-04-10T02:28:51Z'
    }
    yield {
        'id': '2',
        'nome': 'Bruno',
        'source_endpoint': spec['nome'],
        'ingested_at': '2026-04-10T02:28:51Z'
    }


def _lista_avro(diretorio):
    """Retorna os arquivos .avro gerados abaixo do diretório informado."""
    arquivos = []
    for raiz, _, nomes in os.walk(diretorio):
        for nome in nomes:
            if nome.endswith('.avro'):
                arquivos.append(os.path.join(raiz, nome))
    return arquivos


@patch('pipelines.my_pipeline.resolve_credenciais')
@patch('pipelines.my_pipeline.get_token')
@patch('pipelines.my_pipeline.busca_endpoint', new=fake_busca_endpoint)
def test_run_pipeline(mock_get_token, mock_resolve_credenciais, tmp_path):
    """
    Testa o fluxo principal da pipeline de ponta a ponta, validando o conteúdo
    do arquivo de saída gerado. Usa "fakes" e mocks para evitar I/O e erros de serialização.
    """
    # A ordem dos argumentos do mock é o inverso da ordem dos decoradores @patch (de baixo para cima).
    # mock_get_token -> @patch('...get_token')
    # mock_resolve_credenciais -> @patch('...resolve_credenciais')

    # 1. Configurar mocks que são chamados antes da execução da pipeline
    mock_resolve_credenciais.return_value = ("dummy_client_id", "dummy_client_secret")
    mock_get_token.return_value = "dummy_token_value"

    # Converte o path isolado gerado pelo pytest na workspace em string
    temp_dir = str(tmp_path)

    # Parâmetros simulados passados via argv
    argv = [
        '--endpoint=users',
        '--api_path=https://api.degreed.com',
        '--oauth_url=https://degreed.com/oauth/token',
        '--scope=users:read',
        '--dias_delta=7',
        '--secret_manager_project_id=123456789',
        '--client_id=degreed_client_id',
        '--client_secret=degreed_client_secret',
        f'--prefixOut={temp_dir}',
    ]

    run(argv)

    # Valida o arquivo avro gerado no caminho de processamento informado
    arquivos = _lista_avro(temp_dir)

    assert len(arquivos) == 1, "Deveria gerar um arquivo avro para o endpoint informado"
    assert os.path.basename(arquivos[0]).startswith('users_')

    with open(arquivos[0], 'rb') as f:
        reader = fastavro.reader(f)
        campos = [campo['name'] for campo in reader.writer_schema['fields']]
        registros = list(reader)

    assert len(registros) == 2
    assert registros[0]['id'] == '1'
    assert registros[1]['nome'] == 'Bruno'

    # Metadados da camada raw devem estar presentes
    assert 'source_endpoint' in campos
    assert 'ingested_at' in campos
    assert registros[0]['source_endpoint'] == 'users'


@patch('pipelines.my_pipeline.resolve_credenciais')
@patch('pipelines.my_pipeline.get_token')
@patch('pipelines.my_pipeline.busca_endpoint', new=fake_busca_endpoint)
def test_run_pipeline_endpoint_com_janela(mock_get_token, mock_resolve_credenciais, tmp_path):
    """
    Testa a execução para um endpoint limitado a 7 dias por consulta,
    garantindo que o spec resolvido é repassado para a busca.
    """
    mock_resolve_credenciais.return_value = ("dummy_client_id", "dummy_client_secret")
    mock_get_token.return_value = "dummy_token_value"

    temp_dir = str(tmp_path)

    argv = [
        '--endpoint=completions',
        '--api_path=https://api.degreed.com',
        '--oauth_url=https://degreed.com/oauth/token',
        '--scope=completions:read',
        '--dias_delta=30',
        '--secret_manager_project_id=123456789',
        '--client_id=degreed_client_id',
        '--client_secret=degreed_client_secret',
        f'--prefixOut={temp_dir}',
    ]

    run(argv)

    arquivos = _lista_avro(temp_dir)

    assert len(arquivos) == 1
    assert os.path.basename(arquivos[0]).startswith('completions_')

    with open(arquivos[0], 'rb') as f:
        registros = list(fastavro.reader(f))

    assert registros[0]['source_endpoint'] == 'completions'
