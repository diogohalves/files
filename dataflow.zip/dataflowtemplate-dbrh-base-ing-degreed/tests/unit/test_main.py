import sys
import runpy
from unittest.mock import patch


def test_main_execution():
    """
    Testa o ponto de entrada do arquivo main.py garantindo que ele repassa
    os argumentos do sistema (sys.argv) corretamente para a função run do my_pipeline.
    """
    test_args = ['main.py', '--endpoint=users', '--dias_delta=7']

    # Intercepta os argumentos do sistema e a função run para não executar o pipeline real
    with patch.object(sys, 'argv', test_args):
        with patch('pipelines.my_pipeline.run') as mock_run:
            # Simula a execução via linha de comando acionando o __main__
            runpy.run_module('main', run_name='__main__')

            # Verifica se o pipeline.run foi chamado
            mock_run.assert_called_once()
